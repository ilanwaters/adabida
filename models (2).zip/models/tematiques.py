from models import db
from models.ubicacions import Pais  # ← Importem el Pais existent

# ELIMINAR la classe Pais (ja existeix a ubicacions)

class CategoriaTema(db.Model):
    __tablename__ = 'categories_tema'
    
    id = db.Column(db.Integer, primary_key=True)
    pais_id = db.Column(db.Integer, db.ForeignKey('paisos.id'), nullable=False)
    nom = db.Column(db.String(100), nullable=False)
    ordre = db.Column(db.Integer, default=0)
    
    # Relacions
    temes = db.relationship('Tema', backref='categoria', lazy=True)


class Tema(db.Model):
    __tablename__ = 'temes'
    
    id = db.Column(db.Integer, primary_key=True)
    categoria_id = db.Column(db.Integer, db.ForeignKey('categories_tema.id'), nullable=False)
    nom = db.Column(db.String(100), nullable=False)
    ordre = db.Column(db.Integer, default=0)