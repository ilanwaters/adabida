from models import db

class Pais(db.Model):
    __tablename__ = 'paisos'
    
    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(100), nullable=False, unique=True)
    codi_iso = db.Column(db.String(2), unique=True)  # ES, FR, IT...
    
    regions = db.relationship('Regio', backref='pais', lazy=True, cascade='all, delete-orphan')

class Regio(db.Model):
    __tablename__ = 'regions'
    
    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(100), nullable=False)
    pais_id = db.Column(db.Integer, db.ForeignKey('paisos.id'), nullable=False)
    
    municipis = db.relationship('Municipi', backref='regio', lazy=True, cascade='all, delete-orphan')

class Municipi(db.Model):
    __tablename__ = 'municipis'
    
    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(100), nullable=False)
    regio_id = db.Column(db.Integer, db.ForeignKey('regions.id'), nullable=False)

class TraducioUbicacio(db.Model):
    __tablename__ = 'traduccions_ubicacions'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Tipus i ID de l'element traduït
    tipus = db.Column(db.String(20), nullable=False)  # 'pais', 'regio', 'municipi'
    element_id = db.Column(db.Integer, nullable=False)  # ID del país/regió/municipi
    
    # Traducció
    idioma = db.Column(db.String(5), nullable=False)  # 'ca', 'es', 'en', 'fr'...
    nom = db.Column(db.String(200), nullable=False)
    
    # Índex per buscar ràpid
    __table_args__ = (
        db.Index('idx_traduccio_lookup', 'tipus', 'element_id', 'idioma'),
        db.UniqueConstraint('tipus', 'element_id', 'idioma', name='traduccio_unica'),
    )
    
    def __repr__(self):
        return f'<TraducioUbicacio {self.tipus} {self.element_id} [{self.idioma}]: {self.nom}>'