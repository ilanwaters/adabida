from flask import Blueprint, render_template, request, redirect, url_for, session
from flask_babel import _
from models import EntradaBlog, db, ImatgeGaleria
from sqlalchemy import func
import os
import datetime
from sqlalchemy.orm import joinedload
from models import Entrada, Exposicio
from flask_login import current_user

inici_bp = Blueprint("inici", __name__)

@inici_bp.route("/")
def inici_pagina():
    print("💬 Sessió activa?", session.get("usuari_id"))
    if current_user.is_authenticated and "usuari_id" not in session:
        session["usuari_id"] = current_user.id
        session["nom_login"] = current_user.nom_login
    base_path = os.path.join("umberto", "media", "galeria")
    imatges_destacades = []
    exposicions = Exposicio.query.order_by(Exposicio.id.desc()).all()
    exposicions_extra = []  # ✅ Nova llista separada

    imatges = (
        ImatgeGaleria.query
        .options(joinedload(ImatgeGaleria.entrada).joinedload(Entrada.usuari))
        .filter(ImatgeGaleria.destinacio.in_(["galeria", "inici"]))
        .order_by(ImatgeGaleria.data_publicacio.desc())
        .all()
    )

    for img in imatges:
        any_mes = img.data_publicacio.strftime('%Y/%m')
        ruta_fitxer = os.path.join(base_path, any_mes, img.nom_fitxer)

        if os.path.exists(ruta_fitxer):
            if img.nom_fitxer.startswith("expo_"):
                exposicions_extra.append({  # ✅ Aquí!
                    "titol": img.nom_fitxer.replace("expo_", "").split(".")[0].capitalize(),
                    "descripcio": "Col·lecció especial",
                    "carpeta": f"galeria/{any_mes}/{img.nom_fitxer}".replace("\\", "/")
                })
            else:
                imatges_destacades.append(img)

    mostrar_login = session.pop("mostrar_login", False)

    entrades_blog = (
        EntradaBlog.query
        .order_by(EntradaBlog.data_creacio.desc())
        .limit(10)
        .all()
    )

    any_ = func.extract('year', EntradaBlog.data_creacio).label("any")
    mes = func.extract('month', EntradaBlog.data_creacio).label("mes")
    mesos_disponibles = (
        db.session.query(any_, mes)
        .group_by(any_, mes)
        .order_by(any_.desc(), mes.desc())
        .all()
    )

    for exposicio in exposicions:
        exposicio.carpeta = exposicio.carpeta.replace("\\", "/")  # només per seguretat a Windows
        
    return render_template(
        "inici.html",
        imatges_destacades=imatges_destacades,
        exposicions=exposicions,
        exposicions_extra=exposicions_extra,  # ✅ Nova llista enviada al template
        mostrar_login=mostrar_login,
        entrades_blog=entrades_blog,
        mesos_disponibles=mesos_disponibles,
        datetime=datetime.datetime
    )

@inici_bp.route("/manifest")
def manifest():
    return render_template("manifest_etic.html")

@inici_bp.route("/set_language/<idioma>")
def set_language(idioma: str):
    idiomes_permesos = ["ca", "es", "en", "fr", "de", "ru", "eu", "uk"]
    if idioma in idiomes_permesos:
        session["idioma"] = idioma
    return redirect(request.referrer or url_for("inici.inici_pagina"))
