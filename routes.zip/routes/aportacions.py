from flask import Blueprint, render_template

aportacions_bp = Blueprint("aportacions", __name__)

@aportacions_bp.route("/aportacions")
def aportacions():
    """
    Pàgina d'aportacions voluntàries.
    Explica el model de finançament ètic d'Adabida.
    """
    return render_template("aportacions.html")