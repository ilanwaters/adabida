from flask import Blueprint, render_template, session, redirect, url_for, flash, jsonify, request, abort
from models import db, Usuari, Entrada, Experiencia, Estudi, Obra, CarrecPublic, MembreOrganitzacio, Organitzacio
from flask_babel import _
import os
from utils.text_biografic import generar_biografia_entrevista
from flask_login import current_user
from models import PerfilBiografic, ImatgeGaleria, Missatge
from sqlalchemy import or_
from utils import generar_miniatura_entrada
import re
from sqlalchemy import cast, Integer

from models import Pais, Regio, Municipi
pagina_personal_bp = Blueprint("pagina_personal", __name__)

@pagina_personal_bp.route("/pagina_personal")
def pagina_personal():

    usuari_id = session.get("usuari_id")
    if not usuari_id:
        flash(_("Sessió no vàlida"))
        return redirect(url_for("login.login"))

    usuari = Usuari.query.get(usuari_id)
    if not usuari:
        flash(_("Usuari inexistent"))
        return redirect(url_for("login.login"))
    perfil = PerfilBiografic.query.filter_by(usuari_id=usuari.id).first()
    experiencies = Experiencia.query.filter_by(perfil_id=perfil.id).order_by(Experiencia.ordre).all() if perfil else []
    estudis = Estudi.query.filter_by(perfil_id=perfil.id).order_by(Estudi.ordre).all() if perfil else []
    obres = Obra.query.filter_by(perfil_id=perfil.id).order_by(Obra.any.desc()).all() if perfil else []
    carrecs = CarrecPublic.query.filter_by(perfil_id=perfil.id).order_by(CarrecPublic.any_inici.desc()).all() if perfil else []
    missatges = (
        Missatge.query
            .filter(
            or_(
                Missatge.receptor_id == usuari.id,
                Missatge.emissor_id == usuari.id
            )
        )
        .order_by(Missatge.data_env.desc())
        .all()
    )
    for m in missatges:
        print("-", m.assumpte, "de", m.emissor_id)

    if not perfil:
        flash(_("Encara no has creat la teva fitxa biogràfica"))
        text_biografic = ""
    else:
        text_biografic = generar_biografia_entrevista(perfil.id)

    entrades_raw = Entrada.query.filter_by(usuari_id=usuari.id).order_by(Entrada.data_creacio.desc()).all()
    entrades = []
    for entrada in entrades_raw:
        miniatura = generar_miniatura_entrada(entrada, usuari.nom_login)

        entrades.append({
            "id": entrada.id,
            "titol": entrada.titol,
            "any": entrada.any_text,
            "resum": entrada.contingut[:120] + "...",
            "data": entrada.data_creacio.strftime("%d/%m/%Y") if entrada.data_creacio else "",
            "miniatura": miniatura
        })

    # ✅ Obtenim la pestanya activa des de l'URL (per exemple: ?pestanya=entrades)
    pestanya_activa = request.args.get("pestanya", "biografia")  # Per defecte: biografia
    
    imatges_destacades = (
        ImatgeGaleria.query
        .filter(ImatgeGaleria.destinacio.in_(["galeria", "inici"]))
        .order_by(ImatgeGaleria.data_publicacio.desc())
        .all()
    )
    for img in imatges_destacades:
        print("— Fitxer:", img.nom_fitxer)
        print("— Data:", img.data_publicacio)
        print("— Entrada ID:", img.entrada_id)
        print("— Usuari:", img.entrada.usuari.nom_login if img.entrada and img.entrada.usuari else "❌ cap usuari")

    familia = (
        perfil and (
            perfil.pare_nom or perfil.mare_nom or
            perfil.pare_primer_cognom or perfil.mare_primer_cognom or
            perfil.pare_data_naixement or perfil.mare_data_naixement
        )
    )
    # Al final de la funció, abans del return render_template
    organitzacions_admin = []
    organitzacions_vistes = set()

    if usuari:  # Ja sabem que usuari existeix
        print(f"=== DEBUG ORGANITZACIONS USUARI {usuari.id} ===")
        # Necessitem carregar les membresies de l'usuari
        membresies = MembreOrganitzacio.query.filter_by(usuari_id=usuari.id).all()
        print(f"Total membresies: {len(membresies)}")
        for membre in membresies:
            print(f"Membre ID:{membre.id} | Org:{membre.organitzacio.nom} | Rol:{membre.rol} | OrgID:{membre.organitzacio.id}")
            if membre.rol == 'admin' and membre.organitzacio.id not in organitzacions_vistes:
                organitzacions_admin.append(membre)
                organitzacions_vistes.add(membre.organitzacio.id)
            
        print(f"Organitzacions admin úniques: {len(organitzacions_admin)}")
        print("=== FI DEBUG ===")
    else:
        membresies = []

    return render_template(
        "pagina_personal/pagina_personal.html",
        usuari=usuari,
        usuari_id=usuari.id,
        perfil=perfil,
        entrades=entrades,
        text_biografic=text_biografic,
        mode="crear",
        entrada=None,
        pestanya_activa=pestanya_activa,
        imatges_destacades=imatges_destacades,
        experiencies=experiencies,
        estudis=estudis,
        obres=obres,
        carrecs=carrecs,
        familia=familia,
        missatges=missatges,
        organitzacions_admin=organitzacions_admin,
        usuari_organitzacions=[m.organitzacio for m in membresies]
    )

@pagina_personal_bp.route("/eliminar_entrada/<int:entrada_id>", methods=["POST"])
def eliminar_entrada(entrada_id):
    entrada = Entrada.query.get(entrada_id)
    if not entrada:
        return "No trobada", 404

    db.session.delete(entrada)
    db.session.commit()
    return "", 204

@pagina_personal_bp.route("/pagina_personal/<int:perfil_id>")
def mostra_pagina_personal(perfil_id):
    usuari = Usuari.query.get(perfil_id)
    if not usuari:
        flash(_("Usuari inexistent"))
        return redirect(url_for("login.login"))

    # 🔍 Obtenim perfil i text biogràfic
    perfil = PerfilBiografic.query.filter_by(usuari_id=usuari.id).first()
    if not perfil:
        flash(_("Aquest perfil no té fitxa biogràfica"))
        return redirect(url_for("login.login"))

    text_biografic = generar_biografia_entrevista(perfil.id)

    entrades_raw = Entrada.query.filter_by(usuari_id=usuari.id).order_by(Entrada.data_creacio.desc()).all()
    entrades = []
    for entrada in entrades_raw:
        miniatura = generar_miniatura_entrada(entrada, usuari.nom_login)

        entrades.append({
            "id": entrada.id,
            "titol": entrada.titol,
            "any": entrada.any_text,
            "resum": entrada.contingut[:120] + "...",
            "data": entrada.data_creacio.strftime("%d/%m/%Y") if entrada.data_creacio else "",
            "miniatura": miniatura
        })

    missatges = Missatge.query.filter_by(receptor_id=usuari.id).order_by(Missatge.data_env.desc()).all()

    return render_template("pagina_personal.html", 
                       usuari=usuari, 
                       usuari_id=usuari.id, 
                       perfil=perfil,
                       entrades=entrades,
                       text_biografic=text_biografic,
                       mode="crear",
                       entrada=None,
                       pestanya_activa="biografia",  # o "entrades", com vulguis
                       imatges_destacades=[],
                       experiencies=[],
                       estudis=[],
                       obres=[],
                       carrecs=[],
                       familia=False,
                       missatges=missatges)


@pagina_personal_bp.route('/entrades')
def entrades():
    usuari_id = session.get("usuari_id")
    if not usuari_id:
        flash(_("Sessió no vàlida"))
        return redirect(url_for("login.login"))

    usuari = Usuari.query.get(usuari_id)
    if not usuari:
        flash(_("Usuari inexistent"))
        return redirect(url_for("login.login"))

    entrades_raw = Entrada.query.filter_by(usuari_id=usuari.id).order_by(Entrada.data_creacio.desc()).all()
    entrades = []
    
    for entrada in entrades_raw:
        miniatura = generar_miniatura_entrada(entrada, usuari.nom_login)
        
        # Intentar buscar noms si són IDs
        parts_lloc = []
        
        # Municipi
        if entrada.municipi:
            try:
                if entrada.municipi.isdigit():
                    mun = Municipi.query.get(int(entrada.municipi))
                    parts_lloc.append(mun.nom if mun else entrada.municipi)
                else:
                    parts_lloc.append(entrada.municipi)
            except:
                parts_lloc.append(entrada.municipi)
        
        # Regio
        if entrada.regio:
            try:
                if entrada.regio.isdigit():
                    reg = Regio.query.get(int(entrada.regio))
                    parts_lloc.append(reg.nom if reg else entrada.regio)
                else:
                    parts_lloc.append(entrada.regio)
            except:
                parts_lloc.append(entrada.regio)
        
        # Pais
        if entrada.pais:
            try:
                if entrada.pais.isdigit():
                    pai = Pais.query.get(int(entrada.pais))
                    parts_lloc.append(pai.nom if pai else entrada.pais)
                else:
                    parts_lloc.append(entrada.pais)
            except:
                parts_lloc.append(entrada.pais)
        
        lloc = ", ".join(parts_lloc) if parts_lloc else None
        
        # Netejar HTML
        resum = ""
        if entrada.contingut:
            contingut_net = re.sub(r'<[^>]+>', '', entrada.contingut)
            contingut_net = contingut_net.replace('&nbsp;', ' ').replace('&amp;', '&')
            resum = contingut_net[:120] + "..." if len(contingut_net) > 120 else contingut_net

        entrades.append({
            "id": entrada.id,
            "titol": entrada.titol,
            "tema": entrada.tema,
            "any": entrada.any_text,
            "lloc": lloc,
            "resum": resum,
            "data": entrada.data_creacio.strftime("%d/%m/%Y") if entrada.data_creacio else "",
            "miniatura": miniatura
        })

    return render_template('pagina_personal/entrades.html', usuari=usuari, entrades=entrades)

@pagina_personal_bp.route('/nova_entrada')
def nova_entrada():
    usuari_id = session.get("usuari_id")
    if not usuari_id:
        flash(_("Sessió no vàlida"))
        return redirect(url_for("login.login"))

    usuari = Usuari.query.get(usuari_id)
    if not usuari:
        flash(_("Usuari inexistent"))
        return redirect(url_for("login.login"))

    # Carregar organitzacions de l'usuari (copiat de nova_entrada_bp)
    usuari_organitzacions = db.session.query(Organitzacio)\
        .join(MembreOrganitzacio, MembreOrganitzacio.organitzacio_id == Organitzacio.id)\
        .filter(MembreOrganitzacio.usuari_id == usuari.id)\
        .all()

    return render_template('pagina_personal/nova_entrada.html', 
                          usuari=usuari, 
                          usuari_organitzacions=usuari_organitzacions)

@pagina_personal_bp.route('/perfil')
def perfil():
    usuari_id = session.get("usuari_id")
    if not usuari_id:
        flash(_("Sessió no vàlida"))
        return redirect(url_for("login.login"))

    usuari = Usuari.query.get(usuari_id)
    if not usuari:
        flash(_("Usuari inexistent"))
        return redirect(url_for("login.login"))

    # Carregar perfil
    perfil = PerfilBiografic.query.filter_by(usuari_id=usuari.id).first()
    
    # Carregar dades relacionades
    experiencies = Experiencia.query.filter_by(perfil_id=perfil.id).order_by(Experiencia.ordre).all() if perfil else []
    estudis = Estudi.query.filter_by(perfil_id=perfil.id).order_by(Estudi.ordre).all() if perfil else []
    obres = Obra.query.filter_by(perfil_id=perfil.id).order_by(Obra.any.desc()).all() if perfil else []
    carrecs = CarrecPublic.query.filter_by(perfil_id=perfil.id).order_by(CarrecPublic.any_inici.desc()).all() if perfil else []
    
    # Carregar missatges
    missatges = (
        Missatge.query
        .filter(or_(Missatge.receptor_id == usuari.id, Missatge.emissor_id == usuari.id))
        .order_by(Missatge.data_env.desc())
        .all()
    )
    
    # Carregar organitzacions admin
    organitzacions_admin = []
    organitzacions_vistes = set()
    if usuari:
        membresies = MembreOrganitzacio.query.filter_by(usuari_id=usuari.id).all()
        for membre in membresies:
            if membre.rol == 'admin' and membre.organitzacio.id not in organitzacions_vistes:
                organitzacions_admin.append(membre)
                organitzacions_vistes.add(membre.organitzacio.id)

    # Variable familia
    familia = (
        perfil and (
            perfil.pare_nom or perfil.mare_nom or
            perfil.pare_primer_cognom or perfil.mare_primer_cognom or
            perfil.pare_data_naixement or perfil.mare_data_naixement
        )
    )

    # Carregar entrades de l'usuari (copiat de pagina_personal original)
    entrades_raw = Entrada.query.filter_by(usuari_id=usuari.id).order_by(Entrada.data_creacio.desc()).all()
    entrades = []
    for entrada in entrades_raw:
        miniatura = generar_miniatura_entrada(entrada, usuari.nom_login)

        entrades.append({
            "id": entrada.id,
            "titol": entrada.titol,
            "tema": entrada.tema,
            "any": entrada.any_text,
            "contingut": entrada.contingut,
            "data": entrada.data_creacio.strftime("%d/%m/%Y") if entrada.data_creacio else "",
            "miniatura": miniatura
        })

    return render_template('pagina_personal/perfil.html',
                          usuari=usuari,
                          perfil=perfil,
                          missatges=missatges,
                          organitzacions_admin=organitzacions_admin,
                          experiencies=experiencies,
                          estudis=estudis,
                          obres=obres,
                          carrecs=carrecs,
                          familia=familia,
                          entrades=entrades)